const bodyParser=require('body-parser');
const cors=require('cors');


//express packge
const mongoose=require('mongoose');
const express = require('express')


const app = express();

app.use(bodyParser.json());
app.use(cors());

//create of schema
let projuctSchema=new mongoose.Schema({
    
    "title": String,
    "type": String,
    "description": String,
    "filename": String,
    "height": Number,
    "width": Number,
    "price": Number,
    "rating": Number

})
//creating model
let productModel=new mongoose.model("projucts",projuctSchema);

mongoose.connect("mongodb://127.0.0.1:27017/project_products",{ useNewUrlParser: true ,useUnifiedTopology: true} ).then(()=>{
    console.log("Connected with database");

})



app.get('/api/v1/products',(req,res)=>{
    productModel.find().then((products)=>{
        res.send(products);
    });
   
    
})

app.get('/api/v1/products/:id',(req,res)=>{
    //fech all the product
    let id=req.params.id;
    // productModel.find().then((product)=>{
    //     res.send(product);
    // })
    productModel.findById(id).then((product)=>{
        res.send(product);
    })
   
    })

    

app.post('/api/v1/products',(req,res)=>{
    //create movie

    let product=req.body;
   
    let productObj=new productModel(product);
    productObj.save().then(()=>{
        res.send({"message":"product Created"});
    })
    
   
})

//Update
app.put('/api/v1/products/:id',(req,res)=>{

    let id=req.params.id;
    let product=req.body;
//to replce everything
    productModel.updateOne({"_id":id},product).then(()=>{
        res.send({"message":"Movie Updated"});
    });
    // productModel.undateOne({"_id":id},{$set:product}).then(()=>{
    //     res.send({"message":"Movie Updated"});
    // });

})


app.delete('/api/v1/products/:id',(req,res)=>{
    let id=req.params.id;
    productModel.deleteOne({"_id":id}).then(()=>{
        res.send({"message":"product deleted"});

    })
   
    
})




app.listen(3000,()=>{
    console.log("server is running");
});
