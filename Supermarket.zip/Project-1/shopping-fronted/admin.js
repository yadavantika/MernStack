//feach all product

fetch("http://localhost:3000/products")
.then((response)=>response.json())
.then((products)=>{


    
    let productsString="";

    products.forEach((product, index) => {

        

        // let ratingString="";
        // for(let i=1;i<=5;i++)
        // {
        //     if(i<=product.rating){
        //         ratingString+=`<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhESEhISExUSEBAQERgSEA8QEBAQFxcWFxgTFRUYHiggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGzIlICUvLS0tKy0tLi0tLS0tLS0tLy0tLS0vLS0tLS0tLS0tLS0tLS0tLy0tLS0tLTA1LS8tLf/AABEIANoA5wMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAUBAgMGB//EADsQAAIBAgIFCQYFBAMBAAAAAAABAgMRBCEFEjFBUSIyUmFxgZGh0QZCcoKxwRMzYsLwkqLh8RRDsiP/xAAbAQEAAgMBAQAAAAAAAAAAAAAAAgMBBAUGB//EADMRAQACAQIEAwUJAAIDAAAAAAABAgMEERIhMVEFQZETInGB0RQyQmGhscHh8FKSIzPx/9oADAMBAAIRAxEAPwD7iAAAAAAAAAAAAAAAAr44z/7uN+SlGPVrO7v9Ec2dXtq4x+XT59f6X+z/APHusDpKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABzxFVQjKT3Jv8AwV5ckY6TefJKteKYh5vBSbc29rab7czydr234vPr83RmI22ekoVNaKfFZ9u89XhyxlxxePNzrV4Z2dC1EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAqtP17RUOk7vsX+focjxXNtWMcefOfhH9/s2tLTeZsrNHrnfL9zjTG7ZvK60dO14/Mvo/sdrwvJtWcc/GGpnjzTjrNcAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8xpOtr1JPcuSuxfxvvPJ6vN7XPa3l0j4R/t3TxU4aRDbRS5/wAv3JYq7o5JWUOS1Lg792/yubmCfZ3iyi3ONlmd5qgAAAAAAAAAAAAAAAAAAAAAAAAAAAI+PrakJPfay7WamtzexwWtHXpHxn/brcNOK8Q8vM8nR05TtDLn/J+46WljfdrZvJaqJvRRRu74V5W6Lt3bvLLuOjgtvTbsqvHN2LkAAAAAAAAAAAAAAAAAAAAAAAAAAAKjTVXNR4Zvtf8APM8/4xm3tGOPLnPx/wB+7d0teU2U0zkUbcrHQS/M+T9x19DG/F8v5aufyW6idKKtbdhZST6XJfbtX3XeWY/dt8WJ5wkm0rAAAAAAAAAAAAAAAAAAAAAAAAABhu2ZiZiI3kecxU9aTfF3PGZ8k5ck3nzdXHXhiIQ5kKJystAL8z5P3HZ8Oj73y/lqajyXSR14q1GKtO6a37uprNPxsZtTeCJ2ltSnrJPivB70WVtxREsTG07NyTAAAAAAAAAAAAAAAAAAAAAAAAARdIVLQt0su7f/ADrOd4nm4MPDHW3L5ef+/NdhrvbdR1TzEuhVFmZolKz9n/8As+T9x2/DfxfL+WnqfJdxOxVqSyTHGi7SlHjy49/OXjn8xXSdrTX5/X9f3ZnnG7uWogAAAAAAAAAAAAAAAAAAAAAAABVaQqXlbo5d+/8AnUea8SzcebaOleX1/wB+Tcw12qrqpzJbVUWZmiUrPQH/AGfJ+47Xh07cXy/lqajyXKZ1os1GdYlxGzhiJW1Z9F5/A8n4ZP5Sq9tpi3b9v9z+SVY35JRtKwAAAAAAAAAAAAAAAAAAAAADDkuK8SM3rHmztLnUrxSbuslxWZTl1OOlJtvHL80q0mZ2U8meTmZmd5b0I1UrlbVFmZolKx0E/wAz5P3HX0M7cXy/lq5/JbqR0os1dmdYlxmzWeaaex5PsK7W36sw1w2JSilJ5rkvbnbJO/WszOLXYYjhtbnHJm2K2+8Q7rEQ6S8UXxq8E/jj1Q9nbs2U09jXii2MlLdJj1R4ZbE2AAAAAAAACFpSVeMdagoTa2wlyXNfpnsT7VZ9Rr6iM3Dvinn2nzTpwb+88/Q9sINuM9ajJO0lUhaz4N7u+xxLeIaiJ2mdvk3Ps9esLSnpCUleM1JcY6jXiiH2/UT+L9I+jHsadmf+VPpPyIzrc/8Ay/Zn2VOzDxE+k/EjOqzT+OfVn2dezH40ulL+pkftGX/nPrJwV7MfiPi/FkZy5J/FPrLPDHZq2yM2mess7QwRZBsAYGRmBHqlcrKoszNEpT9DPn/L9zp6Wdt2tm8lopG7F1GzOsZ42NnGvVsrLazV1OfhjhjrKyld0Q5a8AAZTMxMx0YbKrLpS8WWRnyx0tPrLHBXs3WJn0n5MtjW6iPxyj7OnZssZPj5IsjxLUR57/KGPY0brHy4R8H6lseK5o6xHpP1R9hVstIPorxsWR4vbzrHqx9nju2WkFvj5lseL186fqj9nnukUK+vsT7XaxvabVRnjetZiO87bfuqvTh6y7G0gpfaH2cp4pX5lVLkzS2/pmt680aeq0VM8b9J7/VdizTT4PnmJwtbC1HGWtTktji2lJcYtbUeZz4b4bcNo2/l0a2reN4WGE9oq0cpatRda1ZeK9Cn2kwzwQucL7Q0pc7Wg+ta0fFehKMtfNCaStKVWMleMlJcU015FkTE9EW4YAAAABgCPWRTaNllUWZmiUpeinz/AJfubuK2yjJCxUjYi6nYlUMWy8MbkV3R27nPtabTvK6I2YMMgAAAAAHJIbmzR1UY4meFjXZjdnZOwmCbzls3LezsaPw2be/l6dvq1smbblVZJWO7EREbQ1GTIARNJaOp14OFSN1ueyUXxi9zKc+CmavDeE6Xmk7w+d6c0DUw0rvlU2+TNLLsktz+p5fW6G+nnfrXv9XSxZq5PironNlc70ZuLvFtPim0/FEN5joytcLpmrHa1NfqWfiicai8deaE44laYfTMJc5OL/qXis/IvrqKz15ITjlYUqsZZxafY7l0WieiExs3MsAADSrC6I2jeEonZAmQosl30e+d3fcvmdlV03WMxkQ2YbIWtuzEMEWQAAA5SxEVvXdmRm0QzFZlo8TwXiY40uDu1dVveR4pS4YhhAbwi20krt7CzHjtktw1jeUbTERvK4weBUc5ZvhuXqz0ej8Prh963O37NHLmm3KOiadJQAAAADWrTUk4ySkmrNNJprg0YtWLRtPRmJmOcPEaf9lnTvUoJyhtlDNzh2dJefaeb1/hU09/Dzjt5x8O/wC7fw6mLcrdXnYnAluO0CDLvAzDCRSds1l2E4E+jj5rfrdufmbFcloQmkJ1LHxe1NeaLYyx5oTSUqE09jTJxMT0QmJhsZYRMXS95d/qY257p1nyMB73d9yVukMWSyCIBrVqxirykorraX1MTMR1ECtpqktjc3+lZeLKrZ6wnGOZRJ6Zm+alH+5+nkV+3meicY482jrSlzpN9+XgOKZ6pRER0daZllKiShiW6MsO+Gw8pu0V2vcu029Lo8mot7vTupyZIpHNd4XCRprLN729r9Een0+lx4K7V9WhfJN55pBsKwAAAAAAADzmnvZqNS9SjaM9rjsjUf2l5PzON4h4VXNvfFyt+k/3/vzbeHUzXlbo8fKlKLcZJxadmmrNM8nkpalpraNph0YmJjeHWBiB3pk4HaJZDDvAkO1MywlQrSW+/aTi8wjNYdViE8mvuicZI80Jp2RZY2lR1teaSya2yds9yzJzaJ2iJJrPZX4n2shspwlLrk1BeGb+hieRFFbX0/Xn7yguEFbzd2VWtKcUhE13J3bbfFtt+LNa0pw70iqUkqmThhLplsMJNMkJUSUIynYHASqZvkx475dnV1nX0Xhtsnv5OUfu1suoivKOq8pUlFJRVkj0VKVpHDWNoaEzMzvLckwAAAAAAAAAAFdpfQ9Ous+TNLkySzXU+K6jR1ugx6qvvcreU/7rC7Fmtjnl07PF43Azoy1Zq3BrmyXFM8hqNLk01+DJHwnyn4OnTJW8bw1plMJu0SyGHeBIbSrxjtaXm/AxNojqzFZlwq6UXux75eiITl7JRj7odXFzltk+xZIrm8ynFYhW46q4TptcJX61lkW4KRkpaJRvO0wmxw1OolKyz3rJ+Rr+0yY54dyYiebWWiH7ku6WXmi6ubfrCExs5Twk4c6LS47V4oSw2pFUpJVMnDCXTLYYSqS2JZt5K2bbLaUteeGsc2JmI5yv9H6K2Sqd0dqXxcew9HovDK4/fyc57NDNqJnlVbnXagAAAAAAAAAAAAADji8LCrFwmrp+KfFPcyrNgx5qcGSN4SpeaTvDx2ltFSw7vfWg3aMt6fCS4nkdd4ffSzv1r5T/ABLqYM0ZeXmrXiuC8Tn+07NmKd3OdeT3+GRGbTKcViHIiyAdYRK7TuKvS/Oh2P6m9pPuypydYdNF4jVdnsfk+JDUY+LnHVis7PRUjWozKbSNqiqW08BTntir8VyX5bSzgrbqjxTDhPQb9yXdL1XoTjSTP3Z9WPbd2KWjausoatm72zVrLa7luHQ5b34dtmbZqRG702jtGxpK+2W9/ZcD0+l0ePTxy693Oy5rXn8k43FQAAAAAAAAAAAAAAAA8r7bYj8qn21H9I/uPOeP5vuYvn/Efy6Wgp1t8nlzzbogADrRp3z3LzZG07EukiqGFNpfnR7H9To6T7kqsnVypE7oPQaKxF1qvatnWjUmu07pLmkXUQlLpl9VUpdI3sKmzrUdtSXRnG/wy5L/APV+46eKeGa27T+/JV13hZnXawAAAAAAAAAAAAAAAAAfP/aLEa+IqPdF6i+XJ+dzxHimb2uqt2jl6f3u7elpw4o9Vac9sAG9Km5Oy/0gTKW42VkVWRcpEYZU2l+fH4X9TpaT7k/FVk6uVIldBOw0mmmtqZq2SenwdVSimu/qZZRCU+mbFVUpdI3sKmyQ6etGUekmvFHSpXijZTvtO6XhamtCMntcVfqlvXjc6mK3FSJU2jaZh1LEQAAAAAAAAAAAAAADliqyhCc3sjGUvBXK8uSMdLXnyiZSpXitFe75nKTbbebbu+tnz21ptMzL0O2zBgEgLKjQ1V1vb6EpjZXM7y0qFFmYcZEYSUul+fH4fuzpaT7k/FVk6udIldBNomrdJa6Orar6nt9SWOdmLRu9FSZtVUSl0jewqbJdI6mJRZ0weTnHhPWXZLP663gb2DlvX8/35/vurv5SkmwgAAAAAAAAAAAAAAAUntdiNWhq76kox7lyn9Ld5yfGsvBppr/ymI/n+G3oqcWTfs8QeOdgAsNHYb338vqWUr5q728kmoYsxCLUNeyUOMiMJKXS3Pj8P3Z0tJ/65+KrJ1c6RK6CbRNW6SfhxUXeja3uvu9DbxzvyVXjzXFI38LWsl0jqYlFm6yqRfSi4vtXKXlrm7TleJ7xt6c4/lCedUo2VYAAAAAAAAAAAAAAB472zxF6sIdCF38Un6JeJ5Xx7Lvlrj7Rv6//AB1dBTak27vPHCbyTgcNry/Ss5ehOlOKUb22hczRfZTCNUKLJwi1DXslDGCwNXEO1FWinaVSX5cfh6T6kdHQ+GZdRO+3L/f76Ksuorjhez9icO6errT/ABNv4rd5OXw7NXq8z1EeF4Yx8Ede/wDTnTqr8W/6PIaU0LWw0rVFeLdozjnCXo+pnC1ekyYJ96OXfybmPLW/RzonLuuT8OKixoF8ML3B1dZda2+p0dPbiamSuywpHWxNazpiMo63Qan3Lnf23N2eVd+3P6/puhHXZJNlWAAAAAAAAAAAAAAAfONK4j8StVnuc3b4VkvJI8FrcvtdRe/5/pHKHfw04McVRqVNyaitryRrRG87LJnbm9Bh6ChFRXe+L4m1WvDGzWtO87lQxZmESrLYrNt5RSV5SfBLeVcM2nhrG8pb7c5Wmj/ZtztLEZLaqcXt+OS29iO/ofBIj38/p9f69Wlm1nlT1elp01FKMUkkrJJJJLgkeirWKxtEbQ0JmZneWxlhpVpRknGSUk1ZppNNdaMWrFo2mN4ZiZjnDyelvZS154fNbXBvNfC3t7H4nndd4N+PB/1+jexaryv6qWlFp2aaadmmrNPg0efis1naY2lu77p9AuhhY4admmv9oux3mk7wrvG8bLuhK6TR38FotETDQvG07JSjdNPerM6VI3jZTLGFd4q+1cl9scn5onjnesb/AA9ORbq6k0QAAAAAAAAAAAAImlsT+HRqT3qDt8TyXm0a2szexwXv2j9fL9VuGnHkir5weBd5d6LwmotZ86S/pjw7TZx02jeWvkvvO0JjLEWcNhJ1nyFaO+b5q7Ok+zxNjTaLLqZ93lHeeny7oZMtcfXr2Xuj9GU6OaV5PnSlnJ9XUupHptJocWmj3Y5956uflz2ydenZNNxSAAAACDpHRVOtm1aW6S29j4o0tXoMWpj3uU946/2uxZrY+nR53EaPnSfKV1ukua/R9R5nU6LLp59+OXeOn9Ohjy1ydHWkUQlKxwVWzs9j8nxOho8/s7bT0n9Gtlrut4HpcbSlpSylNdk13q31i33ma8rTHz/3oT0iXYsRAAAAAAAAAAAAA877Z4i1OFPpzu/hj/lrwOF47m4cNccec/pH97N/QU3vNuyg0Tg9Z68lyYvL9UvRHm8VN+ct/LfaNoXMuGbbySSu2+pGzFZtMVrG8yo6c1hhNEXzq7Ognl87W3sWXadvSeE/iz/9fr3+HT4tXJqvKnr9FvGKSSSslkrZJI7kRERtDSmd2TIAAAAAAAxKKas0mntTzTMWrFo2mN4ZiZjnCrxWirZ0/wCl/ZnD1XhP4sPp9P7bePU+V/VFgrZPI5G0xO0r5ndZYCvfkvatnWuB3fDdVxR7K3WOnw/r9mpmpt70JFTKUXxvHxzv/b5nUtytE/L/AHopjpLqTRAAAAAAAAAAAAA8d7Qp1sV+GtlOMYt7l7zfml3HkvGLzl1XBHSsf262l2x4eKfNY4PAuSUYK0Vld7F2dJ/y5nS6HJm+7yr3+nf/AHNXkzRXr1XGFwcaezNvbJ5yfoupHo9NpMenj3I5+c+c/wC9Gjky2v1SDZVgAAAAAAAAAAA418PGW3bxW01dRpMeePe6906ZJr0V9WjKDv15NHAz6bLprcXpMNut63jZNVXXg3vVm11rPzsd3BqIz4uKOsdY/OPq1bU4bbJKZuKwAAAAAAAAAAAYbMTO0Cr0fomzlOpnKpJzkt1276re9K9jk4PDIm85c3OZnfby+ffb0bWTUcorTpC0SOvEbNVkAAAAAAAAAAAAAADDRiYiY2kRv+PqvWh3x4rqOf8AZJwZPaYennX8vyXe04o2t6u9JWSXBWXZuN+n3YVT1bkmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//9k=" width="20px"/>`;
        //     }
        //     else{
        //         ratingString+=`<img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTEhMVFhUXFRUXGBgXFRgXFhoXFRcXGBUYGBUYHSggGBolHxgdITEhJSkrLi4uHR8zODMtNygtLisBCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAQIDBgcIBQT/xABFEAABAgMFBAcFBQcCBgMAAAABAAIDESExMkFRYQQFEkIGImJxgaHwBxNSkbJygpKx0RQXVJOi0uEWwSMzQ8LT8VNjc//EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwDdIEqCoNpySXLhmg7NmKfSgSnQ0AxRwnbSVmqd93BD2vBAJnU0IsGaT5sckOt7BPqQAZVFSbRkkpUFZ26INL2KDs2YoIFOraDiply4ZpIWC7ircWJKnLh+pxkgqiPwPhr81M+KTjQiwZqyyHOrrMM1f77cP9kCfNjkk5VFSbRkn1J3XsUAUsrO3RBSgqDackHZ8fXzQaXcUDs4Zoa0NALDmn0oe1dwQCZ1NCLBmmPFjkh7VuCd97BAnzY5IDKys7dE7r2KDs24oApQVBtOSgjDDNSOzdxT6UEW0NAMVJrbSVmqgy5qNwKsOeXSDpdnX1RBdbF4jOwiwZ+pqsZ45KljJW38FV9SCfeu+H80Sb8vyRBArdoMU15ckBnWyWGaT5vJA1N3AIaXqzs0ScutbPDJLNZ+SAcjewKac2aSlS2eOSS5fNAFaC3EoK3aAW6pKdLJY5pOdbJeaCiJEkJizEKgsJE5jhJmM+//AAq3Mn1rM25+pqufN5IBIF6w2IaUNTgUNK2zwyUWUNZ45IJ05s00F7EpLl80lPq2SxzQBW7SVuqDMXcQkp6S80nOtmmaBry5IaVNRgEnzeSTlW2eGSAaXqnBNDewKSlS2eOSS5fNA0F7EoK3aHHVJcvmltLJeaAK1FBiEJpPlySc62SwzUOkayp8KC050/s0IEvHH1/tWxhBPFWdkvz0w+SljeHrGs8MhgqrNZ+SBob2BTTmzUESpaTipFer5oJ4H5+vkie57Xr5ogg1qaEWDNNebJD2rcE+pA1F7EIKWVnbondexQdnxQAJUFQbSmnLmg0u4p9CAROhoBYUNb1CLNUOt3BD2rcEDU3sAmvNknfewTuvYoApUVJt0SUqCoNpyQdm3FB2buKCB8PLmtSe2HpVEEUbFAiOY1jQ6KWkhzi4TawkVkGyJGPEMltqI8NaXEyhgEknCVSVy9vzeJ2naI0c/wDUiOcNGk9QeDZDwQZT7N+lkaBtcKDEivdAiuDC17y4Nc6jHMnPhPFIEC2fct9am9gFygwkEEGREiCLQRYRqun+j+8xtWzQY/NEhtd3GXWHg6YQehrzZIKVFSbRkn1IOzexQBSgqDboksOXNB2bMU7ruKBLA3cChrbQCzVO+7gh7VmCAa1NCLAmvNkh7V7BPqQLKi3EIKWVnbondexQdnxQAMBdxKgjDlzzU913FPpQU8Lcz5Ip6nqalANKGpNhyTTmzQUoKzxySXLhmgW0FuJQVspK3VJT6tgGOaGttJeaADOooBaEnjy5JOdbCMM0nzY5IBMqmoNgyQ0trOzRJyrbPDJLLKz8kCWBvYFJYc2aSl1cDikuXDNAFaChFpzQGdRQC0ZpKdDSWOaF062EYZoMP9qe9/cbvi8BkYpEAffnxy14A5c/yWyfbdvTj2mFAH/TZxvGHHEo2eoa3+pa+2DZDGishNte9rRpxGU/C1BYW5/YjvXj2aLsxvQonEzRkWv1hx+8Fq/pZusbNtUSE0SZMOZ9hwmPlUeC9f2Vb1/Z94Q2kyZGBguym+Rh+PGAPvIOgdObNAJ0FCLTmkuXDNJTpZLHNAFaigFuqTx5ckJnWyWGacVZ4jBAnibuSGltQbNEnzY5IKVFZ+SAaUNSbDkmnNmkpUtnjkkuXDNAtoKEWlBWykrdUlOlgGOaGttJeaADOou4hQ54A4jdsA1sUzn1rCMM1FtZW4IKffD4Py/VFTw6O+Z/REFyUrtRipFkhdzQdmzFURXSFLMv90CK8ASNmHr5/JGOmOthZLFW2MnV0+HBXz2vBAOZvYBNebJDrewTTmzQBmL2IQUu1GKDS9ig7NmKBoLuJTQ3cCnddxCam7gEA1vUGCOOLqEWeCHtWYLGPaVvQ7Nu+M6f/EePdMIoZxOqSNQ3iPgg0T0k3odq2qPtB/6kQkfYEmw/6WtC932Ybv8AebUYhFILCfvv6rfLiPgsQW2/Zpu/3exh5HWiuL/ujqs/InxQeR7WN30g7QBnCd49Zn/d8wtewoha4OaZOaQ5pyc0zB+YW7ulm7/2jZI0MCbuHib9pnWb85S8Vo4FB1HubeDdo2eFFFyJDa8d7hMg6gzHgvtdKXWo0WFa89iu9febG+A4z9xEMhjwRZub/Vx+Szt7ibZ8JujTP1YgrMUk1wNBK30Vd15sAqWsleqcFV33sCgai9iEFLtTindexKDs24oAyFmJTTlzQaXcU15ckA5G7gUNb1MkOt3BD2vBAOZvYBNebJO+9gU05s0E8T8kThfmpQW3PnZTTAyqrbGTHFUCoInbqrjhxDrCWQzVQzxGH+EEAcInaMlM5W1nZok5VFptCw72mdJ4m79naYEvexnlocRMMDRNzuGwusAnSs6ykgzGUqGpOOSS5cc1zaeme8P4yNXtS8gKJ/rLeFn7ZH/Gg6SAnQUItOaCtlJW6rm49NN4fxkb8X+EPTTeH8ZG/F/hB0iDPrYZJPmwyXN3+td4fxkb8X+EHTXeNv7ZG/EP0QdIkyqag2DJaf8AbjvOcWBsoM+BpjP+0+bWDwDXH7wWHjptvH+MjfMfovJ27bYkd5iRnufEMpucamQAHkEFvZdndEeyG289zWjvcQB+a37smzthsZDbRrGtaO5oAH5LVHs13f73bA8jqwWl/wB53VYPMn7q24gLRnSjd/7PtUaGBJoeXN+y/rNl3Ay8FvNa39rGwSdBjgWgwnd4m5nkXfIIPh9k29fc7wYw3I7XQiJyHFehnvm2Q+0t9thhsnGowGS5WgRnMe17CWua4Oa4WhzTNpGoIXuDptvH+MjfMfog6PNKGs7Dkply45rm7/Wu8P4yN+Ifoo/1pvCz9sjfi/wg6Sly45oK0FJW6rm7/Wm8P4yN+L/CHppvD+Mjfi/wg6RBnUUAtGadrDJc2npnvD+Mj/jT/We8Lf2yP+NB0kTKpqDhkhpbWdmi1x7J+mMfanRYG0H3j2MD2PkA4t4g1wdISJBLZHGZnYtjillZ26IEpdW0nFJcuOaASoLDaUly8uaCfdH4vzRU+6b8X5Igk9q3BPqQ0oak2HJNObNA7r2Kx7pv0WZvHZ/dB3BEY7jY+0B0iJEYtIJnLQ4LIdBexKCt2krdUHMG/NyR9jie62hha6sjax4HMx3MPMYgLz11DvjdEDa4RhxoYfDyNCD8TXCrXagrR/Tb2fxti4osKcXZhXj54Y/+xow7YpnJBi279k988QxEhsJoDEJa0nLiDTI96ycezjbPigfzH/8AjWHgLLeivTaJs0ocacSDYKzewdkm83snwyQV/u52z4oH8x/9ifu52z4oH8x/9i2fu/bocdgiQnh7DiPyItB0K+lBqf8AdztnxQP5j/7FH7uds+KB/Md/Ytsog8Lol0dGxQi0u44jyC9wEhS60DIecyvdRSECS83pBuhu1wHQXmU5FrhUtcLDLHuyJXokog1RE9nG1gkB8AjA8bxPw4KKP3c7Z8UD+Y/+xbYRBqf93O2fFA/mP/sUfu52z4oH8x/9i2yqI8ZrGlz3BrWiZJMgBmSUGqv3cbZ8UD+Y/wD8a8Hfe6HbK/giRITn4thuc4t+1NoAOk5rKulfT5z5wtkJa2wxbHOz4ByjW3uWBmpqgBfTu/YIseI2FBY6JEdY1orqcgNTQL2uiHQ3aN4OHAOCDOTorh1aWho53aCgxIW9OjPRnZ9gh+7gM65lxRDV75fE7LQUCDxfZz0KO72ue9wdtEQAOAusaK8DSbxnKZ0ErJnMx2fFLaC9iUFbtJW6oHddxT6UBxF3EJPHlyQRJnqaJxsyRBMpUtnjkkuXzQCVBUG05JLDlzQJT6tksc0t0l5pLA3cCjq24WaoLUZ8+zQ+Og1QQgRxEfd8lcInV14WD8lOvNkg1n049l7Is4+whrIhq6DZDd9j/wCN2l06WrUG07O+G90OI1zHtMnNcJOByIXVYpUVOIWPdLeh+z7eyTxKIB1YrZcbdO03snyNUGgdy75jbK/jgul8TTVjhk5uPfaFtfox0rg7YOEdSKBWGT8yw8w8xiFrPpT0W2jYH8MVs2EyZFbP3btJ8ruya22iq8VjyCCCQQZggyIIsIIsKDoZFr3on0+mWwtrNTINi99AIgw+0PHNbBKCoJNQiAiIgIiw3pf02bs5dBgAPjCjnG4w/wDc7SwY5IPe3/v+DsjOKK7rG6wVe7uGA1NFqXpH0ljbY7rnhhg9WG09Uan4nanwkvL2vanxXmJEcXvda4mZP6DRfXuPckfbIohbPDL3YmxrR8T3WNH54TQec0TIAqTIACpmaAAYlbQ6Fey5zuGPt4LW2tgAyccvekXR2RXMioWY9CugMDYAIhlG2nF7hRmYht5ftGp0FFl4pdqTbogt7PBbCaIbGgNAk0NADWjAACgkrkuX+pJYCrTaVA+HlzQTKdLJY5pbpLzQ1obuBQ1vUlZqgTn1rJYZpPm8k1N7AKATbzZIJ992fXyRT7x+SIIHZsxT6UBnUUAtGaT5uXJA77uCHteCEyqbDYENLazs0QO+9gn1JKVDUmw5J2ebNA+zexQdmzFAJ0FCLTmgrZSVuqCxtuxw4rHMexr4ThJ7XCYPzxsWg/aR0ag7BtLWQHksiMMQMdV0McRAHFzAyMp1pWdq6Dnjy4hc29Pd7ftW3x4oPUD/AHbPsQ+qCNCQXfeQeEyGXkNaJlxDQMyTIBdBbLDLWMaTMta0E5kAAlah9nu7vfbawkTbCBinvbRn9RB8FuNAREQEREBaL6RbK5m1x2Ot968z0eeNp8Q4Fb0Wt/alsPBFhxwKPbwO+0yw/I/0oMe6I7mh7XtULZokT3YfxVDQXEtBdwtnQEylM2ZFdBbl3NB2SGIMCGGAZVJPxOcbztSuaN37e6BFhxm3ob2vGvCZy8bPFdQ7LtDYjGOYZh7Wva7suEx5ILvdexQdm3FJYY5oK2UlbqgDs3cUNnY9eNqAzqKAWjNJ83Lkgj7V3BREfK9U8qiJEDRMykbBlqrUNkj1q5f7S0/JBXB4p9a9hWnq1XfqSUurjgckly82aCZP9SRPdO+L80QQTOpoRYM0nzY5JXmtwTXmyQJy62JwQUsrO3RO69iEHZ8UACVBUHHJOzhmg0u4ppy5oBrQ0AxzQmdtJWaodbuCOnjbgg8Hptvb9m2OPHnwubDlDGb3dVnmQfBc2gLbnty3oQ3Z9mnVxMV40bNsOfeXOP3QtStaSQAJkkADMmgCDZ/ss3fwQHxiKxHyH2IdPqLvkFm4Xybo2EQIEOCORjW95A6x8TMqje+9YWzM95GeGjAWuccmtxKD7XOAEyZAVJNklgPSb2ghhMPY+FxFsVwm3uYObvNO9Yz0o6XRdsJYJw4M6MBq7IxDj3WDW1Y4Sgz7cHtEeHcO1gOYedjZOb3tF4d1e9bG2baGxGh7HBzXCYc0zBHeufXNIJBBBBkQRIgi0EYFer0e6RRtjdOGZsJm6G49V2vZdqPNBvJY70+3f77Yokh1ocorfuXv6S5fV0e6RQdsZOGZOF6G6+39RqF6zmggg1BEiNDag56C3z7It7e/3e2GbYLnQiezeh+HCQPBaQ3xsJgR4sE8j3NH2bWnxaQfFZt7F96iHtj4DjJseH/XCm5vjwl6Dd0uXDNDWhpKzVNDdwKHtWYIBM6mhGGahxN4DrfCpOt7BQJznzZILcMVLhWcpiVZ/wC0lca3hsrO3RSMxexQdnxQQKdW0HFTLlwzSQlIXcVAyN3AoJ90PiRRwszRBJ7VuCac2aESoazxySXLjmgaC9iUHZpmkp9WwjHNBWykvNAGYu4hNeXJJzrYBhmnawyQDrdwQ9qpwQmVTUHDJeT0u3r+x7HHjkzLYZ4J/G7qwx+JwQaI9oW9TtO8I75za13umfZhdWmhdxO8U6A7v99tsOYm2HOKfuS4f6i1Y6vR3ZvmJs7IjYJ4XROEOeLwa2fVb8Myam2yxBs7pV0yhbLNjJRI3wz6rPtkfSK91q1XvPeUXaIhiRnlzj8gMmiwDRfIVkvQ/oVtG8HcTRwQAetFcKUtawc7vIYnAh4e7d3xdoiCFBY573WNaMMSTY0DM0W6OhXs6g7Hwx9q4Y0ekhbDhnDhBvO7R8ALVkvRvo7s+wQuGAyU5cTj1okQ5udj3ASGAXoOMyHGs6SlZXDP1kgxfpj0Ig7wm8yhx5DgitE55CIOcedKGVDpTpDuDaNii+62hnCbWuFWPGbHY91oxAXTYHDrPyXyb33TB2mGYG0MERjs7QcC02tcMwUHMGzbQ+G8PhuLXtMw4GRC2b0V6eMiyhbVJkSwPsY/KfwO8jpYvE6b+zyNsRdEgzjbOKl0uvDHbAtHaFMwFhKDN/apu/hjw4wFIjOE/ah/q0j5LEt1be7Z48KO22HEa+WYaQS3xEx4q/F31Ffs42eIeNjXB0MuvMImJA4tIJEjZSVi85B1ZBjNexrwZw3AOb3OEwVWe1UYLDfZNvb3272AmboDjBI0bJ0M/gcB4FZkaVNZ+SAcjewTTmzSUqWk45JLlxzQBkL2JQVu0zSU6WEY5oK2Ul5oAzF3EIbK3cknPrWAYZpPmwyQUzZqiq96PhRAlKgqDacklhy5qAcrMVP0oEp0NmBQ1tpKzVDLG7gonO37voIJtqaEWBNebJO+9gn1IApUVJtGS1f7cN5hsKBsrTfcYr/ssowHvc4n7q2gNL2K0Z7ZYD27wD3A+7fCYIZw6s+JoOYJJ+8EGBo0EkAAkkgACpJNgAxK9Dcm5I+1xfdbOwvdaTY1o+J7uUehNbv6FdAYGwgRHyixpf8AMIo04iG3ly4rTpYgxLoP7Li+UbeALW0LYE5F3/6HAdkVzIsW2oMFrWhrWhgaAGtaAAALABgO5VntWYKD2rcEFp4JdMz4p0yl3Z2/+leFKi8bQn1J3XsUEWXazt0UjIVabTkg7P3vXzUS+G7igmVOHlzWtOm3swZF4o2xBsOJaYRPDDiZlhshu0unSpWywRLsevG1D2ruCDlXa9mfCe6HEY5j2mTmuEnA6gq0uj+lvRPZ9vbwxxwxQP8AhxGy4xofibPA+EjVaL6VdFdo3fE4Y7ZtJ6kRtWO8eV3ZNe8VQZb7GN7e62p8DCOybR24UzLv4S75Lc4pZUm3Rc4ez/Z4sTeOyiDPibFa9xyhtP8AxScgWzb3uAxXR47NuKABKgqDacklhy5oOzdxT6UAidDQCwoa20lZqh1u4Ie14evkgTnU2iwKl87RexGn/pVHW9ggH48UFj35+CJ/V+qL6Ov6kiCLbKAWqOIS4jdxCmc62SwzViJEn1qylZSuvcgRIk/smwS1/wAK6xvDerOzT5qIIkOKVThkq7NZ+SBZQ1OBTTmzSUqWzxySXL5oArQUItK+bbtghbQzgiw2RGTmWvaHCYxkcdV9Mp0sljmltbJeaD5d37vgwG8MCEyFDnMtY0NBOZAtK+rXlySc+tlgk+byQCZVNQbNENKGpNhyScq2zwySUqWzxyQNObNLaC9iUly+aSn1bJY5oArZSVuqCtRdxCW6S80nOtksM0EdrlyVMSKG21nYMqTFFLnyrKZPL3Kyy2ciZioy/wAYSQVMaZ9YzmaUs8fWKnatmZEaYUVjXhwqHNDmkagq7ZS2eOSS5fNB8W7N0QNnBbs8GHCJvFjGtn3kCZX2itlCLdUlPq5YpbSyXmgCtRQC0Jry5JOdbJYZpPm8kAmVTdwCGl6s7NEnKts8Mks1n5IByN7AppzZpKXVtnjkkuXzQT7t2aKPc9r180QURpmRNosGamG2VebJVSletwT6kDUXsQoaZWVJtU917FJTu+KAMhdxKacuagHK7jqp+lANaGjcChreoRZqoc4Ada7h6FUNZcXggmeJvYBNebEJ33sE7r2KAKXanFBSgqMSg7NuKDs3cUDTlzQjA3cCn0odbuCAa3qSs1Q5m9gEPa8PXyUEVrewQWgw8Uzet7/0+avClRU4hPqQdm9igiUrtQbVIskLuJQdmzFRLEXcQgnQ3cChreoBZqkxjdwQ9qzBANamhwCa82Sp46yN7D1ZaqgPx5oGovYhBS7WduiDS9ig7PigAYC7iUlhy5oNLuKfSgjgZmiTZl+aIKo15vrFDfHrAqUQRDvn1kkDm9ZoiChlw9/6KeT1mpRBZ2243x+kq47l7z9SIgrffHrNG3z6yUogiDed6xVMG671giIAues0iXB6zREExuX1kpiXx6zREAX/AFkkG871iiIIg2OUNuFEQQbnj/sqo1jURBYd/wAxvf8A7vX0c/rJEQId8qIHN6zREEQ7h9ZIbg9YoiCyiIg//9k=" width="20px"/>`;
        //     }
        // }
        

        productsString+=`
        <tr>
          <td>${index+1}</td>
          <td>${product.title}</td>
          <td>${product.price}</td>
          <td>${product.type}</td>
          <td>${product.rating}</td>
          <td>
              <button class="btn btn-success">Update</button>
              <button class="btn btn-danger onclick="deleteProduct(${product.id},this)">Delete</button>
          </td>
         </tr>
        `;

    });




    document.getElementById('product_container').innerHTML=productsString;
})

let childrens;
function updateDataReady(ele,id){


    // displaying the modal

        document.getElementById('parent_popup').style.display="block";

    // getting the data ready 

    childrens=ele.parentNode.parentNode.children;
    
    document.getElementById("id").value=id;

    document.getElementById("name").value=childrens[1].innerText;
    document.getElementById("description").value=childrens[2].innerText;
    document.getElementById("price").value=childrens[3].innerText;
    document.getElementById("type").value=childrens[4].innerText;


}

function closeModal(ev){

    if(ev.target.className=="parent_popup")
    {
        document.getElementById('parent_popup').style.display="none";
    }

    
}

function deleteProduct(id,ele){

    ele.parentNode.style.display="none";

    fetch("http://localhost:3000/product?id="+id,{
        method:"DELETE"
    })
    .then((response)=>response.json())
    .then((data)=>{
        
        document.getElementById("message").innerHTML=
        `<p class="alert alert-success">${data.message}</p>`;

       
    })
}

function updateProduct(){

    let product={};

    let id=document.getElementById("id").value; 
    product.title=document.getElementById("name").value;
    product.description=document.getElementById("description").value;
    product.price=document.getElementById("price").value;
    product.type=document.getElementById("type").value;

    

    fetch("http://localhost:3000/product?id="+id,{
        method:"PUT",
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify(product),
        
      
    })
    .then((response)=>response.json())
    .then((product)=>{

        

        document.getElementById('parent_popup').style.display="none";

        childrens[1].innerText=product.title;
        childrens[2].innerText=product.description;
        childrens[3].innerText=product.price;
        childrens[4].innerText=product.type;


        document.getElementById("message").innerHTML=
        `<p class="alert alert-success">Product Updated Successfully!!!</p>`;

    }).catch((err)=>{
        console.log(err);
    })    



}


