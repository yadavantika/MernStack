const http=require('http');
const fs=require('fs');
const url=require('url');

// creation of server 

// reading the file 


const avengerString=fs.readFileSync("./avenger.json","utf-8");
const avenger=JSON.parse(avengerString);


const server=http.createServer((req,res)=>{

    //const path=req.url;
    //const path=url.parse(req.url);
     console.log(req.method);

    const path=url.parse(req.url,true);
    


    res.writeHead(200,{
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "OPTIONS, POST, GET, PUT, PATCH, DELETE",
        "Content-Type":"application/json"
    });

    if(path.pathname=="/" || path.pathname=="/avenger"){

        res.end(avengerString);
        console.log(avengerString);
        
    }
    else if(path.pathname=="/avenger"){

        if(req.method=="GET")
        {
            const id=path.query.id;

            const singleData=avenger.filter((ele)=>{
                return ele.id==id;
            })
            res.end(JSON.stringify(singleData));
        }
        else if(req.method=="POST"){

            let body="";
            req.on('data',(data)=>{
                body+=data;
            })

            req.on('end',()=>{
                let avenger=JSON.parse(body);
                avenger.push(avenger);
                fs.writeFile("./avenger.json",JSON.stringify(avenger),(err)=>{
                    res.end(JSON.stringify({message:"avenger added"}));
                });

            })
      

        }
        else if(req.method=="PUT"){

            // product id 
            const id=path.query.id;

            // product data
            let body="";
            req.on('data',(data)=>{
                body+=data;
            })

            req.on('end',()=>{
                let avenger=JSON.parse(body);

                // index will not work 

                avenger.forEach((ele)=>{
                    if(ele.id==id){

                        ele.name=avenger.name;
                        ele.age=avenger.age;
                        ele.planet=avenger.planet;
                        ele.weapone=a.weapon;
                       

                    }
                })

                
                fs.writeFile("./avenger.json",JSON.stringify(avenger),(err)=>{
                    res.end(JSON.stringify({message:"avenger updated"}));
                });

            })

        }
        else if(req.method=="DELETE"){

            // product id 
            const id=path.query.id;

            avenger.forEach((ele,index)=>{
                if(ele.id==id){
                    avenger.splice(index,1);
                }
            })


            fs.writeFile("./avenger.json",JSON.stringify(avenger),(err)=>{
                res.end(JSON.stringify({message:"avenger deleted"}));
            });

            



        }
        
        
    
      
    }
    else {
        res.writeHead(404,{
            "Content-Type":"application/json"
        });
        res.end(JSON.stringify({message:"Not Found anything for this URL"}));
    }

    

});

server.listen("3000","127.0.0.1",()=>{
    console.log("server is running");
})
