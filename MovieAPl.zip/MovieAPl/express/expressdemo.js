const bodyParser=require('body-parser');
const cors=require('cors');


//express packge
const mongoose=require('mongoose');
const express = require('express')


const app = express();

app.use(bodyParser.json());
app.use(cors());

//create of schema
let movieSchema=new mongoose.Schema({
    "name": String,
      "universe": String,
      "year": Number,
      "rating": Number,
      "revenue": Number,
      "poster": String

})

let movieModel=new mongoose.model("movies",movieSchema);

mongoose.connect("mongodb://127.0.0.1:27017/movies",{ useNewUrlParser: true ,useUnifiedTopology: true} ).then(()=>{
    console.log("Connected with database");
})





app.get('/api/v1/movies',(req,res)=>{
    movieModel.find().then((movies)=>{
        res.send(movies);
    });
   
    
})


    

app.post('/api/v1/movies',(req,res)=>{
    //create movie

    let movie=req.body;
   
    let movieObj=new movieModel(movie);
    movieObj.save().then(()=>{
        res.send({"message":"Movie Created"});
    })
    
   
})

app.put('/api/v1/movies/:id',(req,res)=>{

    

})


app.delete('/api/v1/movies/:id',(req,res)=>{
    
   
    
})




app.listen(3000,()=>{
    console.log("server is running");
});
