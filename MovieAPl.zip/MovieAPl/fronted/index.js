
//Disply function for univrse
function displayMovies(movies){
   
    if(movies.length!=0){
        let moviesString="";

        movies.forEach((movie,index)=>{
    
            let{poster,name,rating,revenue,year}=movie;
              
            moviesString+=`
            
              <div class="card" style="width: 18rem;margin-left:70px;margin-top:30px;background-color:black;color:white;">
                  <img src="${movie.poster}" class="card-img-top" alt="...">
                  <div class="card-body">
                  <h5 class="card-title">${name}</h5>
                 <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                 </div>
                 <ul class="list-group list-group-flush">
                 <li class="list-group-item" style="background-color:black;color:white;">Rating : ${movie.rating}</li>
                 <li class="list-group-item" style="background-color:black;color:white">Revenue : ${movie.revenue}M</li>
                 <li class="list-group-item" style="background-color:black;color:white;">Released : ${movie.year}</li>
                 </ul>
                </div>
            `;
    
        })
    
    document.getElementById('movies').innerHTML=moviesString;
    }
    else{
        document.getElementById('movies').innerHTML='<h2 style="margiin-top:30px; color:white">NO Movies Found</h2>';
    }

}

//fech data
let moviesData;
let moviesBackup;

fetch("http://localhost:3000/api/v1/movies")
 .then((res)=>res.json())
 .then((movies)=>{

    
    moviesData=movies;
    moviesBackup=movies;
    displayMovies(moviesData); //call display moviesdata
      
    

})
.catch((err)=>{
    console.log(err);
})

// serch by name

let filterMovies;
function FilterByName(){
     let mainArray;
    if(filterMovies.length!=0){
        mainArray=filterMovies;

    }
    else{
        mainArray=moviesData;
    }

    let movieName=document.getElementById("name").value;
    
     filterMovies=mainArray.filter((ele)=>{
        return ele.name.toLowerCase().includes(movieName.toLowerCase);
    })


    displayMovies(filterMovies);

    
    
}
//Rating
function FilterByRating(){

    let MinRating=document.getElementById('min-rating').value;
    let MaxRating=document.getElementById('max-rating').value;

    document.getElementById('minR').innerHTML=MinRating;
    if(Number(MaxRating) <Number(MinRating)){
        MaxRating=MinRating;

       document.getElementById('maxR').innerHTML=MinRating;
       document.getElementById('max-rating').value=MaxRating;
   }  

  

    let movies=mainArray.filter((ele)=>{

       return ele.rating>=MinRating && ele.rating<=MaxRating

   })
   displayMovies(movies);
}

//Filter by universe

function filterByUniverse(){
    let mainArray;
    if(filterMovies.length!=0){
        mainArray=filterMovies;

    }
    else{
        mainArray=moviesData;
    }
     let universe=document.getElementById("universe").value;

     if(universe!=""){
     let mainArray;
     if(filterMovies.length!=0){
         mainArray=filterMovies;
     }
     else{
         mainArray=moviesData;
     }
          let universe=document.getElementById("universe").value;
         if(universe!=""){
             filterMovies=main.filter((ele)=>{
                 return ele.universe=universe;

             })


     displayMovies(movies);
    }
    else{
        displayMovies(mainArray);
    }


}

function sortMovies(property,what){
    
    //let movies;
    let mainArray;
    if(filterMovies.length!=0){
        mainArray=filterMovies;

    }
    else{
        mainArray=moviesData;
    }
     //let movies;
    if(what=='asc')
    {
         moviesData=mainArray.sort((a,b)=>{
            return a[onwhat]-b[property];
    
        }) 
    }
    else{
        moviesData=mainArray.sort((a,b)=>{
            return b[property].a[property];
        })
    }

    displayMovies(filterMovies);


}
//for genreFiter
let genre=[];
function FilterByGenre(currBtn){
    let mainArray;
    if(filterMovies.length!=0){
        mainArray=filterMovies;

    }
    else{
        mainArray=moviesData;
    }
    
    let buttons=document.getElementsByClassName('genre');

    if(currBtn.value!="all"){
        
        if(currBtn.classList["value"].indexOf("btn-primary")>=0){

            currBtn.classList.remove('btn-primary');
            currBtn.classList.add('btn-dark');

            console.log(genre);

            let removeIndex=genre.indexOf(currBtn.value);
            genre.splice(removeIndex,1);

            if(genre.length==0){
                buttons[0].classList.remove("btn-darl");
                buttons[0].classList.add("btn-parimary");
            }
        
        }
        else{

        genre.push(currBtn.value);

        buttons[0].classList.remove("btn-primary");
        buttons[0].classList.add("btn-dark");

        currBtn.classList.remove('btn-dark');
        currBtn.classList.add('btn-primary');

        }

        
    }
    else if(currBtn.value=="all"){

        

        genre=[];

        currBtn.classList.remove('btn-dark');
        currBtn.classList.add('btn-primary')

        for(let i=1;i<buttons.length;i++){
            buttons[i].classList.remove("btn-primary");
            buttons[i].classList.add("btn-dark");
        }

    }

    if(genre.length!=0){
        filterMovies=moviesData.filter((ele)=>{
            return checkArrays(ele.genre,genre);
        })
    
        displayMovies(filterMovies);
    }
    else{
        displayMovies(mainArray);
    } 

  //console.log(genre.toString());
}

function checkArrays(arr1,arr2){

    let counter=0;
    arr2.forEach((ele)=>{
        if(arr1.includes(ele)){
            counter++;
            return;

        }
    })
    if(counter>0){
        return true;

    }
    return false;
}




















