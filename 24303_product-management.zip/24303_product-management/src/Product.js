class Product {
  constructor(product) {
    this.name = product.name;
    this.price = product.price;
    this.quantity = product.quantity;
    this.color = product.color;
  }
}

export default Product;
